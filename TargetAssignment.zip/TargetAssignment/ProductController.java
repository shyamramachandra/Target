package com.myRetail.productservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.myRetail.productservice.domain.Product;
import com.myRetail.productservice.repository.ProductRepository;


@RestController
public class ProductController {

@Autowired
ProductRepository productRepository;

@Autowired
ProductService productService;

@PostMapping(value="/product/id") 
public Product save(@RequestBody Product product) {
		
	return productRepository.save(product);
}


@GetMapping(value="/product/id")
public Product findByProductID(@PathVariable Integer productId){
  Product product = productRepository.findByProductID(productId);
}

@PutMapping(value="/product/id") 
public Product update(@RequestBody Product product) {
		
	return productRepository.save(product);
}



}
