package com.myRetail.productservice;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.apringframework.boot.test.context.SpringBootTest;
import org.apringframework.boot.test.mock.mockito.MockBean;
import org.apringframework.test.context.junit4.SpringRunner;

import com.myRetail.productService.domain.Product;
import com.myRetail.productService.service.ProductService;


@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductControllerTest {

@MockBean
ProductService productService;
@Test
public void findByProductID() {
  assertTrue(productService.findByProductID(13860428).getPrice() == 13.49);
}

@Test
public void testAddProduct_returnsNewProduct(){
       when(productService.save(any(Product.class))).thenReturn(new Product(13860430, "The Big Computer Macin(Widescreen)", 16.34, "USD"));
aasertThat(productService.save(new Product(13860430, "The Big Computer Macin(Widescreen)", 16.34, "USD")),is(notNullValue()));

}


}